echo "Buh/Proto_fino_a_6_2_rete_n_01" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_01/ ./Proto_fino_a_6_2_rete_n_01/res/ ./Proto_fino_a_6_2_rete_n_01/ >sims_2_1.log
 echo "Buh/Proto_fino_a_6_2_rete_n_02" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_02/ ./Proto_fino_a_6_2_rete_n_02/res/ ./Proto_fino_a_6_2_rete_n_02/ >sims_2_2.log
 echo "Buh/Proto_fino_a_6_2_rete_n_03" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_03/ ./Proto_fino_a_6_2_rete_n_03/res/ ./Proto_fino_a_6_2_rete_n_03/ >sims_2_3.log
 echo "Buh/Proto_fino_a_6_2_rete_n_04" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_04/ ./Proto_fino_a_6_2_rete_n_04/res/ ./Proto_fino_a_6_2_rete_n_04/ >sims_2_4.log
 echo "Buh/Proto_fino_a_6_2_rete_n_05" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_05/ ./Proto_fino_a_6_2_rete_n_05/res/ ./Proto_fino_a_6_2_rete_n_05/ >sims_2_5.log
 echo "Buh/Proto_fino_a_6_2_rete_n_06" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_06/ ./Proto_fino_a_6_2_rete_n_06/res/ ./Proto_fino_a_6_2_rete_n_06/ >sims_2_6.log
 echo "Buh/Proto_fino_a_6_2_rete_n_07" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_07/ ./Proto_fino_a_6_2_rete_n_07/res/ ./Proto_fino_a_6_2_rete_n_07/ >sims_2_7.log
 echo "Buh/Proto_fino_a_6_2_rete_n_08" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_08/ ./Proto_fino_a_6_2_rete_n_08/res/ ./Proto_fino_a_6_2_rete_n_08/ >sims_2_8.log
 echo "Buh/Proto_fino_a_6_2_rete_n_09" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_09/ ./Proto_fino_a_6_2_rete_n_09/res/ ./Proto_fino_a_6_2_rete_n_09/ >sims_2_9.log
 echo "Buh/Proto_fino_a_6_2_rete_n_10" ; nice ./acsm2s ./Proto_fino_a_6_2_rete_n_10/ ./Proto_fino_a_6_2_rete_n_10/res/ ./Proto_fino_a_6_2_rete_n_10/ >sims_2_10.log
 